paramètres qtcreator

projects
build
shadow build DEBUG   : Qt-project/shadow-build
shadow build RELEASE : Qt-project/release

run
working directory : Qt-project/shadow-build
Enable QML ticked

