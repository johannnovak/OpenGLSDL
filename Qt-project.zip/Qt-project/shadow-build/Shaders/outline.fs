#version 140

out vec4 fragColor;

void main()
{
	fragColor = vec4(0.0f, 0.0f, 0.0f, 1.0f);
}