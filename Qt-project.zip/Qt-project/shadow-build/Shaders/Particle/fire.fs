#version 130

in vec4 fColor;

out vec4 fragColor;

void main()
{
	fragColor = fColor;
}
