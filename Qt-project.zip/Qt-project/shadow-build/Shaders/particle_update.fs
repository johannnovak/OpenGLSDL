#version 400

in vec4 fColor;

out vec4 fragColor;

void main()
{
	fragColor = fColor;
}